SAÚDEMOÇAMBIQUE V4
==================

Estrutura:
- index.html — página inicial
- noticias/index.html — lista de notícias
- noticias/bem-vindo-v4.html — artigo de exemplo
- empregos/index.html — área de empregos

Para publicar uma nova notícia:
1. Crie um novo ficheiro .html dentro de noticias/.
2. Adicione o link da nova notícia em noticias/index.html.
3. Faça o commit no GitHub.
4. O GitHub Pages publicará a alteração automaticamente.

Para publicar uma vaga:
- Adicione somente informação verificada.
- Não invente requisitos, salário, prazo ou link de candidatura.
- Se algo não puder ser confirmado, escreva “não confirmado”.

Contacto:
84 414 1093
dylonaugustocusse@gmail.com
WhatsApp: https://wa.me/258844141093
